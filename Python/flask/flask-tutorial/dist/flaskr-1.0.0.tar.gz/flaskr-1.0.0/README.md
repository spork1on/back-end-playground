# flask-tutorial

a simple blog made in flask through a tutorial from its website.
